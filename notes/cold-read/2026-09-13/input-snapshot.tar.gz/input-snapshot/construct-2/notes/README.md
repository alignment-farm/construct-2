# Research notes

Background findings, research perspectives, and organizational proposals for
Construct-2's agent memory research.

- [PREVIOUS_RESEARCH.md](PREVIOUS_RESEARCH.md) — Synthesis of prior Construct experiments, their findings, limitations, and implications for future claims.
- [RESEARCH_PERSPECTIVES.md](RESEARCH_PERSPECTIVES.md) — Research perspective on agents, memory, learning, and the allocation of knowledge across external state, code, and model weights.
- [ANCILLARY_STUDY.md](ANCILLARY_STUDY.md) — Proposed organization for independent ancillary studies and how their publications inform the shared research program.
