# Update source selection

Read [README.md](README.md) first. It owns the starting question, initial
expectation, background, and links to this study's eventual findings.

This ancillary study investigates whether an agent can improve later decisions
by choosing which experience to use for parameter updates during an episode:
self-generated text, environmental observations, summaries, or no update.

The study owns its methods, implementation, experiments, analysis, and local
publication. Revise the question when evidence warrants it and explain material
changes. Keep work within the user's stated resources and expectation; return
to the user when those boundaries need to change. The parent project's study
map supplies background, not a mandatory experimental protocol.

### Research practice

- Start with the closest papers and available implementations. Distinguish
  existing conclusions, replications, and proposed extensions; record exact
  paper and implementation versions.
- Separate exploratory observations from prospective tests of a developed
  claim. Preserve inputs, outputs, configurations, failures, and the evidence
  needed to reproduce reported comparisons.
- Judge useful adaptation through later behavior, not training loss alone.
  Keep information access and costs explicit across comparisons, including
  selection, summaries, verification, and skipped updates.
- Keep working documentation proportional to the investigation. Publish a
  local research note or paper with supporting evidence and reproduction
  instructions; link it from the README. Negative and inconclusive results
  are valid outcomes. External submission is a separate user decision.

### Model resources

- Dedicated Mac Studio M1 (64 GB unified memory), commissioned for model serving
  over Tailscale backed by docker model runner (preferred). `curl https://mac-studio-7hr7.taile71f88.ts.net/engines/v1/chat/completions ...`
- Local open-weight models with `docker model`
- OpenAI models with `codex`
- SpaceXAI models with `agent`

The Mac Studio was reported by the user on 13 September 2026; its endpoint and
installed model revisions are not recorded here. Verify gradient or mutable-state
access separately before using a serving resource for a neural treatment.

### Dependency management

- Use `uv` for Python package and project management.
- Use `docker` for local models and `compose`/Dockerfile(s) for complex resources, if/when needed.
