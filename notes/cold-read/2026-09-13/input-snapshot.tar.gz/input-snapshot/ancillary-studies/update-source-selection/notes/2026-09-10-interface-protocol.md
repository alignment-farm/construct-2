# Interface repair and gated rerun

10 September 2026, specified before inspecting the revised interface outputs.

Test one interface revision: stateless presentation of the full historical
prefix plus explicit current position, inventory, and inspection status on
every action. Label prior plans as unexecuted. Replace boolean possession
messages with natural language and explicitly state that returning empty-handed
is not success. The command list stays unfiltered. The interface never reads
the hidden correct location; it summarizes only observable environment state.
This bundles changes; it is not an ablation of their individual causes.

Development: 12 checkpoints using new crate identifiers. Validation: 24
checkpoints, new identifiers plus permutations of room and object names, with
the same task grammar. These remain synthetic, correlated development-family
cases; validation is a frozen interface check, not broad generalization.

Run no-update MLX 0.6B competence on development, then Docker 4B on the same
generated prefixes. If the 0.6B model completes at least 10/12 development
checkpoints and at least 5/6 in each condition, run the frozen 24-checkpoint
validation with it. Require at least 20/24 total and 10/12 in each condition
before rerunning the four adaptation branches. These thresholds are investigator
engineering criteria, not significance tests. If it fails, record the failure
and use Docker competence to decide whether training at a larger scale is
justified. Do not repeatedly tune this interface on validation outputs.

If the gate passes, run the full four-source diagnostic on those validation
cases. This is still exploratory reuse of competence cases, not a prospective
source-selection test. Keep the previous update mechanism unchanged and include
all candidate generation costs. No source chooser, parameter grid, larger model
download, or new resource commitment is part of this bounded iteration.
