# Docker runtime and context-competence diagnostic

10 September 2026. Exploratory engineering result; no parameter updates.

## Runtime correction

This session is on an Apple M3 Max MacBook Pro with 48 GB memory and 40 GPU
cores. With Full Access, Docker Model Runner is reachable: client v1.2.6,
server v1.2.8, llama.cpp b9879-metal, fingerprint `72874f5`. The sandboxed
probe's access failure did not establish runner unavailability. Both probes
are retained in `evidence/2026-09-10-smoke/`.

Used the already installed `huggingface.co/qwen/qwen3-4b-gguf:Q4_K_M`, artifact
`sha256:618c80458ca4012b132ef1847bcd49ec5f923c3d9df35fdc534715085108e9f3`.
Inspection reports 4.02B parameters, Q4_K_M, 2.32 GiB, and the internal name
“Qwen3 4B Instruct Awq.” This is artifact identity, not a verified upstream
weight revision. It is Qwen3, not aTTT's Qwen3.5. No download was needed.
This replaces the proposed 0.6B model only for the inference diagnostic.

## Method and observations

Twelve deterministic episodes require moving to a room, inspecting a box,
taking an object, and returning to the lobby. Correct object locations are
supplied explicitly; the last six episodes also contain a conflicting claim
labeled unverified. Requests use temperature zero, a 128-token limit, and
`/no_think`. There is no training, selection, or summary generation.

The environment executes only exact valid commands and reports resulting
state. Invalid commands leave state unchanged. Expected actions are computed
from current state and never sent as scorer labels. Four actions is the
minimum successful horizon, with no recovery budget. The parser can remove
a completed reasoning block but does not repair case or punctuation.

| Exploratory prompt | Correct actions | Invalid actions | Completed episodes | Wall seconds | Total tokens |
| --- | ---: | ---: | ---: | ---: | ---: |
| Abstract command grammar | 0/48 | 48/48 | 0/12 | 9.57 | 8,184 |
| Concrete command list | 48/48 | 0/48 | 12/12 | 7.85 | 10,090 |

The first run produced literal placeholders, punctuation, and premature
inspection, such as `move ROOM amber.`. After inspecting that failure, one
prompt change listed all six literal command strings and requested no
punctuation. The list includes actions with unsatisfied preconditions; it
does not reveal the valid next action. Identical cases and scoring were used.

These are development observations, not held-out tests or independent trials.
Room and object combinations repeat, and the task is easy. The success supports
this interface for further diagnostics, not robust competence, useful source
variation, or learning. Timing comparisons are not controlled benchmarks: the
first run includes cold-start overhead and prompt caches may be reused.
Peak memory was not measured. Raw responses preserve usage and backend timings.

## Adaptation boundary

The installed CLI and [Docker API reference](https://docs.docker.com/ai/model-runner/api-reference/)
expose inference and model management, not gradient updates or optimizer state.
The reference HTML is saved under `evidence/2026-09-10-smoke/`. This does not
prove every underlying engine lacks training, but it does not establish a
usable training interface through `docker model`. Changed prompts must not
be reported as parameter adaptation.

The earlier MLX installation failed in the sandbox on DNS resolution before
installation. `pyproject.toml` retains the audited MLX commit as an optional,
unresolved and untested adaptation dependency. No lockfile was produced.
The Docker harness uses only Python's standard library. No MLX installation
was retried after the user directed work to Docker.

Continue using Docker for inference. Before an update-source comparison,
establish a separate training path and compatible weight/adapter loading, or
run all compared policies in a shared trainable runtime. An MLX-updated model
cannot simply be compared against this quantized Docker baseline and the
difference attributed to source selection. Retain the bounded runtime smoke
test before model acquisition or pilot expansion. No adaptation findings or
selector comparison have been produced.

## Reproduction and evidence

From the project root, use new output directories (existing ones are refused):

```sh
uv run --no-project scripts/docker_competence.py --output evidence/repeat-abstract
uv run --no-project scripts/docker_competence.py --concrete-actions --output evidence/repeat-concrete
```

Requires the recorded model installed in Docker Model Runner and localhost
TCP API access on port 12434. The harness has a nine-minute request-start
budget and 60-second request timeout. API failures are recorded and stop the
run. Confirm the tag resolves to the recorded artifact ID; the script saves
inspection metadata but does not enforce tag immutability.

- `evidence/2026-09-10-docker-competence/`: all initial requests/responses,
  cases, summary, runtime/model metadata, original runner snapshot and hash.
- `evidence/2026-09-10-docker-competence-concrete/`: revised-prompt records and
  runner snapshot; invoke that runner with `--concrete-actions`.
- `evidence/2026-09-10-smoke/`: before/after-permission probes, API documentation,
  and setup failure record. The earlier audit is unchanged.

These observations form a local research note. A parameter-adaptation
manuscript and LaTeX/PDF publication remain downstream of adaptation evidence.
