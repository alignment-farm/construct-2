# Episode diagnostic: completion floor prevents source comparison

10 September 2026. Exploratory result on the 48 GB Apple M3 Max.

## Finding

None of Self, Env, Summary, or no update completed a retrieval leg on the
24 frozen checkpoints with Qwen3-0.6B. The earlier first-action improvements
did not translate into four-action task completion in this richer interface.
This is an inconclusive source-selection diagnostic, not evidence that source
selection cannot help a competent agent.

| Update source | Completed legs | Correct actions | Invalid actions |
| --- | ---: | ---: | ---: |
| None, full context | 0/24 | 12/96 | 1/96 |
| Self | 0/24 | 11/96 | 5/96 |
| Env | 0/24 | 12/96 | 0/96 |
| Summary | 0/24 | 12/96 | 3/96 |

All completion rankings tie, so a retrospective best-source choice also
completes zero legs. It cannot supply evidence for a selector. Validity is
not success: most failures are legal but unproductive moves to lobby. In the
verified-correction condition, the model usually moves to the correct room
then returns without inspecting or taking. In the unverified-bulletin condition,
every source scores zero correct actions. All 432 MLX generations finish below
the 64-token ceiling; these failures are not output truncation.

## Frozen design and its scope

The [protocol](2026-09-10-episode-protocol.md) was written and the cases saved
before model calls. Twelve scripted episodes each contain two fresh retrieval
legs, alternating between verified corrections and unverified conflicting
bulletins. All rooms connect; retrieving requires move, inspect, take, return.
The transition function was checked on all cases for successful four-action
paths and rejected take/inspect preconditions before running.

Earlier inventories and latest observations are deterministic environment
inputs. Self is generated before the latest observation; Summary is generated
afterward. Therefore the correction can make Self stale, while a bulletin
leaves earlier verified inventory authoritative. This changes evidence
reliability by construction, not demonstrated neural training utility.
No researcher-authored assertion is mislabeled as model-generated Self text.

Each checkpoint is evaluated from the common **no-update reference state**:
same initial adapter tensors, seed, and empty optimizer state. All continuations
receive the full raw prefix with earlier Self and latest observation. None is
an explicit-context control. Summary derives from that same prefix, with no
hidden scorer information. Candidate generation is shared overhead and charged
even when a candidate is not used. There is no separate summary-context branch.

These are local interventions in recorded prefixes. They do not test a live
policy's persistent adaptations, nonzero optimizer snapshots, or feedback from
an earlier adapted rollout into a later checkpoint. The paired legs are
scripted resets, not a continuous model-generated trajectory. No claim of
episode-level selector value follows. The correlated 24 checkpoints are
development examples, not independent statistical trials.

Training uses the pinned Qwen3-0.6B/MLX environment from the
[smoke test](2026-09-10-adaptation-smoke.md): rank 8, scale 2, all query
projections, dropout 0, two AdamW steps at 5e-4, weight decay 0, seed 17.
Loss is unweighted shifted cross entropy with float32 logits for loss
computation. Repetition weighting is not implemented; this is not an aTTT
replication. Every updated branch changed its adapter hash, gradients were
finite, initial adapter hashes matched at resets, and the full frozen base
hash was unchanged at run end. Exact reset-logit and repeated-branch checks
were established in the preceding smoke test, not repeated in this run.

## Follow-up competence check with Docker

After inspecting the 0.6B failure, use the already-installed Docker Qwen3-4B
artifact identified in the [Docker note](2026-09-10-docker-smoke.md) on exactly
the recorded initial messages, including 0.6B-produced Self prefixes. Subsequent
actions and environment feedback are generated live by the 4B model, not replayed
from 0.6B failures. No training is performed in this follow-up.

The first Docker attempt used default reasoning behavior and exhausted the
64-token budget without action content on all 36 completed requests. It was
interrupted (exit 130), with its logs and runner retained. One in-flight request
may not be recorded; the retained 36 responses account for 9,630 reported tokens.
The corrected attempt adds `/no_think` to the system message. All 96 responses
then end normally, with 20,968 reported tokens and 14.71 seconds wall time.

Qwen3-4B completes **9/24 legs: 9/12 corrections and 0/12 unverified bulletins**,
with 62/96 correct and 18/96 invalid actions. This is a useful but incomplete
competence check, not a model-size experiment: model, quantization, runtime,
and thinking control differ from MLX. It is not a control for parameter-update
effects. Its main implication is that the unverified-evidence condition still
fails even with the available larger inference model.

## Costs and reproducibility

The MLX diagnostic took 57.15 seconds, with peak MLX allocation 1.83 GB
(not whole-system memory). It made 24 Self and 24 Summary generations, plus
384 action generations. Candidate generation used 3,789 prompt tokens and
805 generated tokens; action generation used 80,817 prompt tokens and 1,169
generated tokens. Training used 144 optimizer steps and 2,338 total next-token
targets, taking approximately 4.69 seconds. Different source lengths mean equal
step counts do not imply equal compute. No selector or verification model was
used. No additional model downloads, paid APIs, or remote compute were needed.

Evidence: `evidence/2026-09-10-episodes/` contains frozen cases, pre-run task
checks, source snapshots, raw generation events, losses, norms, adapter hashes,
full action/state traces, the failed and corrected Docker checks,
`analysis.json`, and a per-checkpoint CSV. The directory's SHA256SUMS covers
the retained evidence. Analysis is descriptive and reproducible:

```sh
uv sync --locked --extra adaptation
uv run --locked --extra adaptation python scripts/episode_diagnostic.py --cases evidence/2026-09-10-episodes/cases.json --output evidence/episode-repeat
uv run --no-project python scripts/episode_docker_check.py --no-think --run evidence/episode-repeat --output evidence/docker-episode-repeat
uv run --no-project python scripts/analyze_episodes.py evidence/2026-09-10-episodes
```

Model acquisition instructions are in the smoke-test note. Existing run output
directories are refused. The analyzer expects the recorded `run-01` and optional
`docker-no-think` subdirectory layout. Runtime guards check one hour and five-GB
MLX peak allocation at logging boundaries rather than continuously.

## Decision

Do not develop a dynamic selector from these results. First diagnose baseline
task competence with explicit goal/state presentation and then freeze a revised
interface on fresh development cases. The installed Docker 4B model can support
that work without further downloads. Training a larger model is not yet the
most informative next step: the current interface fails the unverified condition
even in that inference check. Preserve this negative run rather than overwrite
it or describe the earlier first-action gain as episode success.
