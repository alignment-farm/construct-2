# Frozen exploratory episode diagnostic

Specified before running the episode diagnostic on 10 September 2026.

Twelve scripted episodes each have two checkpoints, alternating in order between
a verified inventory correction and an unverified conflicting bulletin. Each
checkpoint starts a fresh retrieval leg in lobby. Earlier inventory and the
latest observation are researcher-authored environment events, not model text.
Self is generated from the earlier inventory before the latest event; Summary
is generated from the full prefix afterward. Corrected locations change hidden
task state; unverified bulletins do not. Room/object/order patterns are balanced
by deterministic construction, not random sampling.

Freeze cases to JSON before model calls. For each checkpoint, generate Self and
Summary once with the frozen base policy. Branch into none/Self/Env/Summary from
identical initial adapters and empty optimizers. All continuation branches see
the full prefix, including the earlier Self output and latest observation.
Summary contains no additional external information. Candidate generation costs
are shared overhead and must be reported even for no update. None is therefore
an explicit-full-context baseline. There is no context-removal memory test.

Use pinned Qwen3-0.6B and MLX dependencies from the smoke test, rank 8, scale 2,
all query projections, dropout 0, seed 17, two AdamW steps at 5e-4 and zero weight
decay. Use unweighted shifted cross entropy, now casting logits to float32 for
loss computation. This precision change applies to every updated branch; do
not compare its losses numerically to the previous bfloat16 smoke losses.
No repetition weighting or repetition history is involved. Checkpoint states
follow a common no-update reference, so they have empty optimizer state. This
does not test a nonzero optimizer snapshot or persistent adaptive trajectories.

Roll out four exact commands in a deterministic environment. Record complete
inputs, rendered prompts, outputs, token IDs, source texts, losses, finite
gradient norms, adapter hashes, validity, and task success. Invalid actions do
not change state. Taking requires being at the box and previously inspecting
it; success requires returning with the object to lobby. Full completion,
correct actions, and invalid actions are separate measures. Test the transition
function before running. Verify all frozen base tensors remain unchanged.

Report every checkpoint, descriptive source rankings, ties, conditions, and
paired differences versus no update. A retrospective per-checkpoint best score
is an optimistic diagnostic only. Do not infer selector value from it. Cases
are correlated development examples; no significance test or held-out claim.
No fixed mixture, matched random selector, cadence tuning, or live selector is
tested at this stage. If all sources tie or a fixed source wins throughout,
retain that outcome rather than tune to manufacture a selection opportunity.

Budget: one local model, no additional model downloads, 96 four-action rollouts,
48 candidate generations, 144 optimizer steps. Cap at one runtime hour and check
five-GB peak MLX allocation at log boundaries. No larger-model expansion is
included. Archive source snapshots at run start and preserve failures.
