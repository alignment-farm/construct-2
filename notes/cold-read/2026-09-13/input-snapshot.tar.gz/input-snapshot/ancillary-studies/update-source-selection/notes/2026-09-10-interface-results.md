# Competent-baseline source diagnostic

10 September 2026. Exploratory result; no dynamic selector was built.

The original task interface produced a completion floor. A revised observable-state
interface still failed on 0.6B and non-thinking Docker 4B development runs (0/12 each).
Enabling reasoning did not rescue 0.6B, but Docker 4B then completed 12/12.
Native 4B completed 12/12 development and 24/24 frozen validation cases, passing
the engineering thresholds before adaptation was run. Validation uses new crate
identifiers and permuted names within the same grammar; it is not broad generalization.

The [protocol](2026-09-10-interface-protocol.md) and subsequent
[reasoning/resource addendum](2026-09-10-reasoning-addendum.md) distinguish the
initial failed revision from the exploratory reasoning follow-up. The latter uses
one pinned native 4B download on the existing 48 GB machine, with a 16 GB MLX
guard and one-hour per-run guard. Source generation remains non-thinking; action
reasoning has a 1,024-token ceiling. All comparisons below use the same native runtime.

| Source | Completed legs | Correct actions | Invalid actions | Generated action tokens |
| --- | ---: | ---: | ---: | ---: |
| None | 24/24 | 96/96 | 0/96 | 24,936 |
| Self | 24/24 | 96/96 | 0/96 | 25,621 |
| Env | 24/24 | 96/96 | 0/96 | 26,075 |
| Summary | 24/24 | 96/96 | 0/96 | 26,146 |

No update already attains perfect completion. These cases supply no completion-level
advantage for source selection, even with retrospective choice. Source-dependent
reasoning lengths are descriptive costs, not a controlled speed comparison.
Full context and explicit reliability labels make the task solvable without updates.
Do not tune away this ceiling to manufacture a selector benefit.

Every updated adapter changed; gradient norms were finite; reset logits matched
exactly; and frozen base tensor hashes remained unchanged. The no-update actions
exactly reproduced the prior validation run. The interface contract tests passed:
legal solutions succeed, invalid preconditions fail, the prompt does not read the
hidden location, and command lists remain unfiltered.

Updated token streams differed from matched no-update streams in 288/288 action calls, despite the completion-level comparison above.

The source comparison took 46.29 minutes with 9.63 GB peak MLX allocation.
It used 432 generations, 144 optimizer steps, and 2,250 prediction targets.
Total prompts contained 105,869 tokens; outputs contained 103,519 tokens including reasoning and candidates.
There were 0 configured-ceiling hits. Loss decreased between steps in 72/72 updated branches.
Peak allocation is not whole-system memory, and step counts do not equalize costs.
No paid API, remote job, fixed-mixture search, random selector, or dynamic policy was used.

The full checkpoint traces, source texts, token IDs, model manifest, gate records,
costs, failures, and implementation snapshots are in `evidence/2026-09-10-interface/`.
Its `analysis.json` includes every completed interface/decoding stage, and the
SHA256SUMS manifest covers the evidence. All outcomes are exploratory and cases are correlated.

Reproduce the final comparison from the project root, after acquiring the pinned
model described in the addendum and installing `uv.lock`:

```sh
uv sync --locked --extra adaptation
uv run --locked --extra adaptation python scripts/episode_diagnostic.py --state-interface --thinking --model models/qwen3-4b --memory-gb 16 --cases evidence/2026-09-10-interface/validation.json --output evidence/native4-repeat
uv run --no-project python scripts/analyze_interface.py
uv run --no-project python scripts/report_interface_results.py
```

The analyzers use the recorded evidence directory layout. Existing run outputs
are refused. The compiled local research report is linked from README; its source
and bibliography are under `paper/`.

This completes the focused feasibility investigation: updates work, behavior must
be checked beyond first actions, and this synthetic full-context setup does not
justify selector development. A broader study would need a separately specified
task/resource tradeoff with useful acquisition and room for improvement, followed
by prospective comparisons against strong fixed policies. That is a new study
design decision, not an unperformed required step in this diagnostic.
