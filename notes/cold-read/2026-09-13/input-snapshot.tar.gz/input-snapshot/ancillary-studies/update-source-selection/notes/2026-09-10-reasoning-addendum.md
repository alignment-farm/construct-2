# Reasoning-mode follow-up and resource revision

The first interface revision failed on 0.6B MLX and 4B Docker without thinking
(0/12 completions each). Validation cases have not been evaluated or inspected
through model outputs. A bounded decoding follow-up enables thinking with a
1,024-token action-generation ceiling while keeping the interface fixed.
Source candidate generation remains non-thinking with a 64-token ceiling.
All reasoning tokens and latency must be counted. This follow-up was developed
after the first interface failure, so development evidence is exploratory.

The Docker 4B follow-up had 35/35 correct actions at the point a native 4B
download was started; the 0.6B reasoning run still showed precondition errors.
The user has directed autonomous continuation on the available 48 GB machine.
Revise the investigator-proposed tiny-model envelope for one Qwen3-4B copy
(approximately 8 GB weights), a 16 GB MLX allocation guard, and the existing
one-hour per-run runtime guard. This uses existing local hardware and disk,
with no paid APIs, remote jobs, or multi-model sweep. The initial envelope was
an investigator proposal rather than a user-specified numerical cap.

Pin native weights to Qwen/Qwen3-4B revision
`1cfa9a7208912126459214e8b04321603b3df60c`, retrieved from the model metadata API.
Docker's quantized artifact has separate provenance; its results are a feasibility
check, not an adaptation control. All final source comparisons must use native
MLX 4B for both updated and unchanged branches.

Apply the same competence thresholds to native 4B: at least 10/12 development
completions and 5/6 per condition, then at least 20/24 validation completions
and 10/12 per condition. Only on passing both gates run the four-source
diagnostic on the fixed validation cases. Reuse makes this an exploratory
source diagnostic, not held-out source-selection inference. If the native
model fails either gate, report it without another interface/parameter sweep.

Acquire the exact native checkpoint from the project root:

```sh
HF_HOME=$PWD/.cache/huggingface uv run --locked --extra adaptation python -c 'from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen3-4B", revision="1cfa9a7208912126459214e8b04321603b3df60c", local_dir="models/qwen3-4b", allow_patterns=["*.json","*.safetensors","*.txt","*.jinja","LICENSE","README.md"])'
```

The pre-run evidence copy of this addendum omits this later reproduction-command
addition; its decisions and model revision are unchanged.
