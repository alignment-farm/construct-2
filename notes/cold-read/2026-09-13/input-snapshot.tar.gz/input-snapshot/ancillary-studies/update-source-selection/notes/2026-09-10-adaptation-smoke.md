# First parameter-update smoke test

10 September 2026. Exploratory implementation and acquisition diagnostic.
This is neither an aTTT replication nor the planned episode-level pilot.

## Result

A trainable local route works on the 48 GB M3 Max. The pinned MLX environment
loads the pinned Qwen3-0.6B weights and performs two query-projection LoRA
updates. Every branch has finite gradient norms, changed adapter tensors,
unchanged base tensors, exact reset logits, and a reproducible repeated Env
branch. Updates also change later generated action choices.

| Source fact room | No update | Env | Self | Summary |
| --- | ---: | ---: | ---: | ---: |
| amber | 9/12 | 12/12 | 8/12 | 11/12 |
| blue | 9/12 | 11/12 | 9/12 | 9/12 |
| green | 9/12 | 10/12 | 9/12 | 8/12 |

Entries are exact correct first actions on the same 12 development probes.
The amber result was inspected before adding the blue/green checks; these
are exploratory observations, not prospective tests. Env ranks first in all
three checks. There is no demonstrated advantage for dynamic selection.

## What was run

The Docker inference harness remains available. Because the inspected Docker
interface did not expose a parameter-training path, all update and no-update
branches here use the same native MLX model, tokenizer, precision, and generation
implementation. The previous Docker Qwen3-4B scores are not a control for these
0.6B results. Docker CLI packaging supports GGUF and safetensors artifacts;
adapter interchange and equivalent Docker deployment have not been verified.

After Full Access was granted, `uv sync --extra adaptation` successfully
installed MLX LM commit `86b48c461feebf87c58788655b7e57b5574b9e6d`.
The full dependency resolution is in `uv.lock`; installation output is retained.
Weights are `Qwen/Qwen3-0.6B`, revision
`c1899de289a04d12100db370d81485cdf75e47ca`, loaded without quantization from
the downloaded bfloat16 checkpoint. A manifest records every downloaded file's
size and SHA-256. Models plus virtual environment use under 2 GB locally.

Treatment: query projections in all 28 layers, rank 8, MLX scale 2, dropout 0,
seed 17, AdamW with learning rate 5e-4 and weight decay 0, fresh optimizer per
branch, two full-sequence shifted next-token cross-entropy steps. Other AdamW
settings use the locked implementation defaults. The loss is **unweighted**:
aTTT repetition weighting and online repetition history are not implemented.
This choice isolates training mechanics before implementing episode behavior.

All branches start from the same materialized random LoRA initialization with
zero-output initial adapters. The harness restores trainable tensors and the
seed, creates a fresh optimizer, and constructs fresh generation caches.
It hashes all base tensors before and after the branch sequence, checks exact
initial adapter hashes and first-probe logits at every reset, and repeats Env
after Self and Summary to test branch isolation. Final Env hashes and actions
match its earlier branch exactly in all three runs. These checks establish
fresh-state branching, not restoration of a nonzero episode optimizer state.

Each source prefix states that a key is in box0 in the named room and the
agent is in the lobby. Env is that exact text. Self is the frozen model's answer
to a request for its next action and reason. Summary is the frozen model's
one-sentence summary of the same prefix. These are actual model outputs, not
injected self-authored text. All sources and generation inputs are preserved.
The amber Self output adds unsupported puzzle/unlocking detail; blue/green
Self outputs omit the room. Summary and Self generation costs are recorded.

The 12 probes ask for the first action needed to retrieve a key, given its
location in context and a concrete command menu. Room patterns repeat four
times; box IDs vary. Six include a conflicting assertion explicitly labeled
unverified. The expected answer is `move ROOM`; no answer label is passed
to generation. Generation is greedy, with `enable_thinking=False` and a
48-token ceiling. Outputs are stripped of surrounding whitespace and scored
by exact equality. No command repairs or constrained decoding are used.

**Interpretation limit:** these are independent first-action probes, not
four-action rollouts or checkpoints within one evolving episode. Most probes
describe a different fact from the adaptation source, and each supplies its own
correct fact. Improvements can therefore reflect general behavior or formatting
changes; they do not demonstrate retention or useful episode memory. The 12
scores are correlated and must not be treated as 12 independent trials.

## Costs and checks

Each run makes 74 generations: 12 initial competence probes, two source
generations, and 12 probes for each of five branches (including the duplicate
Env check). The no-update branch duplicates the initial competence measurement
as a reset check. Each run performs eight optimizer steps including repeat Env.
Total over three runs: 222 generations and 24 steps. Env uses 16 prediction
targets per step in each run; source lengths differ, so steps are not equal
compute. Per-source target lengths, losses, norms and generated token IDs are
in the event logs. Selection cost is zero because there is no selector.

The amber run took 12.06 seconds and reported 1.83 GB peak MLX allocation.
Per-run wall time and MLX peak allocations are in the summaries; this is not
whole-system peak memory. All runs fit the proposed ten-minute smoke budget.
The harness checks a five-GB MLX allocation ceiling at logged boundaries,
not continuously. Download and environment setup are outside those runtimes.
No paid API calls or remote compute were used.

## Decision and continuation

The update/reset mechanism is usable and affects behavior. A larger model is
not yet needed to establish that engineering fact. The next informative step
is the planned common-prefix, four-action diagnostic with source utility
changing during episodes. It must preserve source provenance and information
access and add episode-state/repetition-history handling. Current results
support keeping Env as a serious fixed baseline, not developing a selector
from these tiny rankings. No statistical or novelty claim follows.

## Reproduce

```sh
uv sync --locked --extra adaptation
HF_HOME=$PWD/.cache/huggingface uv run --locked --extra adaptation python -c 'from huggingface_hub import snapshot_download; snapshot_download("Qwen/Qwen3-0.6B", revision="c1899de289a04d12100db370d81485cdf75e47ca", local_dir="models/qwen3-0.6b", allow_patterns=["*.json","*.safetensors","*.txt","*.jinja","LICENSE","README.md"])'
uv run --locked --extra adaptation python scripts/mlx_smoke.py --source-room amber --output evidence/repeat-amber
uv run --locked --extra adaptation python scripts/mlx_smoke.py --source-room blue --output evidence/repeat-blue
uv run --locked --extra adaptation python scripts/mlx_smoke.py --source-room green --output evidence/repeat-green
```

Existing output directories are refused. Each completed run preserves its
runner snapshot, sources, JSONL events and summary. Reproduce on compatible
Apple Silicon; exact floating-point equivalence on other hardware is untested.
`evidence/2026-09-10-adaptation/` contains setup/download logs, model manifest,
and all three runs. SHA256SUMS covers saved evidence. `run-01` used the original
runner before the room flag was added; its source room was amber.
